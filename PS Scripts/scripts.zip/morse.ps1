$morse = @{'.-' = 'a';'-...'='b'}
$morse.reverse = @{'a' = '.-';'b' = '-...'}

$convert = Read-Host 'Enter what you want to convert'
$convert = $convert.split(' ')

for($i = 0; $i -eq $convert.Length){
    $i = 0
    $convert[$i] = $morse.$convert[$i]
    $i = $i + 1
}

$convert