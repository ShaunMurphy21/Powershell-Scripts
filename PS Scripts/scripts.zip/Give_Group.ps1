﻿Import-Module ActiveDirectory


function Get-User{
    $script:user = Read-Host enter users username
    if(Get-ADUser -Filter 'sAMAccountName' -eq $user ){
        echo 'user found'
    }
    else{
        $try = Read-Host user not found - type y to try again
        if($try -eq 'y'){
            Get-User
        }
    }
}

function Assign-Group{
    $valuePairs = [ordered]@{'1' ='RestrictedDataAcquisition';'2' = 'RestrictedDatadevelopment'; '3' = 'RestrictedRaise';'4' = 'RestrictedRaise_Sensitive';`
    '5'= 'RestrictedRAISESummaryReports'; '6' = 'RestrictedFurtherEducationandSkills';'7' = 'RestrictedFurtherEducationandSkillsRemit'; '8' = 'RestrictedSocialCare';`
    '9'='RestrictedSocialCare_Sensitive';'10'='RestrictedSchools';'11'='RestrictedRasam';'12'='RestrictedEarlyYearsTeam';'13'='RestrictedIndependentSchools';`
    '14'='RestrictedL3VAANDPIDPDATA';'15'='RestrictedOBREPORTS'}
    $valuePairs
    $group =  Read-Host 'Enter a number'
    $group = $valuePairs.$group
    echo $group

    Add-ADGroupMember -Identity $group -Members $user
    $again = Read-Host 'Would you like to add another?'
    if($again -eq 'y'){
        Get-User
        Assign-Group
    }
}

Get-User
Assign-Group
